<option value="0">Proveedores</option>
<option value="1" {{ $val == '1' ? 'selected="selected"' : '' }}>Compras</option>
<option value="2" {{ $val == '2' ? 'selected="selected"' : '' }}>Clientes</option>