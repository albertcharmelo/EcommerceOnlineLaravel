@extends('web.layout')
@section('content')
@include('web.partials.indexSlider')
@include('web.partials.indexCategory')
@include('web.partials.indexProduct')
@include('web.partials.indexClientSide')
@include('web.partials.indexBlog')



@endsection
