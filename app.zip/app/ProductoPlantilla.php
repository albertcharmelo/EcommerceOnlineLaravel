<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductoPlantilla extends Model
{
    protected $table = 'producto_plantilla';

    protected $guarded = [];
}
