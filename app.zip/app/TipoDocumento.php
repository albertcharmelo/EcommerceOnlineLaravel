<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class TipoDocumento extends Model
{    
    protected $fillable = ['nombre','operacion', 'descripcion'];
}
