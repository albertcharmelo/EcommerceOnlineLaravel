ALTER TABLE `productos`
	ADD COLUMN `imagen` VARCHAR(150) NULL DEFAULT '' AFTER `atributo`;