<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilospdfs.css')); ?>">
    <title>REPORTE DE INVENTARIO</title>
</head>

<body>
    <header>
        <p><strong>DEVIA RD</strong></p>
        <p>FECHA: 22/07/2021</p>
    </header>
    <main>
        <div class="container">
            <h5 style="text-align: center"> INVENTARIO DE ALMACEN <h5>
                    <hr>

                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Referencia</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Stock</th>
                                <th scope="col">Precio</th>
                                <th scope="col">Precio Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($articulo->id); ?></th>
                                    <td><?php echo e($articulo->referencia); ?></td>
                                    <td><?php echo e($articulo->nombre); ?></td>
                                    <td><?php echo e($articulo->stock); ?></td>
                                    <td><?php echo e($articulo->precio); ?></td>
                                    <td><?php echo e($articulo->stock * $articulo->precio); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
    </main>

    
</body>

</html>
<?php /**PATH C:\laragon\www\devian\resources\views/panel/inventario/report.blade.php ENDPATH**/ ?>