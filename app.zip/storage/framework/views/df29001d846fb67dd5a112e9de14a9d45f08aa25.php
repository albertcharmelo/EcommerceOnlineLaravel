

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/selectric.css')); ?>">
    <link rel=" stylesheet" href="<?php echo e(asset('summernote/dist/summernote-bs4.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('panel.partials.validation-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="section">
        <div class="section-header">
            <h1 class="section-title">Consultar Proveedor</h1>
            <div class="section-header-breadcrumb">
                <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
                <div class="breadcrumb-item"><a href="#">Google Maps</a></div>
                <div class="breadcrumb-item">Geocoding</div>
            </div>
        </div>

        <div class="section-body">

            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-body">

                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nombre</label>
                                <div class="col-sm-12 col-md-7">
                                    <input readonly type="text" id="nombre" name="nombre"
                                        value="<?php echo e(old('nombre', $proveedor->nombre)); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label for="tipo_documento"
                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Tipo
                                    Documento</label>
                                <div class="col-sm-12 col-md-7">
                                    <select readonly title="Indique el tipo de documento" name="tipo_documento_id"
                                        id="tipo_documento_id" class="form-control selectric">
                                        <?php $__currentLoopData = $tipodocumentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipodocumento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tipodocumento->id); ?>"
                                                <?php echo e($proveedor->tipo_documento_id == $tipodocumento->id ? 'selected' : ''); ?>>
                                                <?php echo e($tipodocumento->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Número</label>
                                <div class="col-sm-12 col-md-4">
                                    <input readonly min="0" id="num_documento" name="num_documento" type="text"
                                        value="<?php echo e(old('num_documento', $proveedor->num_documento)); ?>" class="form-control"
                                        required>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Dirección</label>
                                <div class="col-sm-12 col-md-7">
                                    <textarea readonly id="direccion" name="direccion"
                                        value="<?php echo e(old('direccion', $proveedor->direccion)); ?>"
                                        class="summernote-simple"></textarea>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Telefono</label>
                                <div class="col-sm-12 col-md-4">
                                    <input readonly id="telefono" name="telefono" type="text"
                                        value="<?php echo e(old('telefono', $proveedor->telefono)); ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group row mb-4">
                                <label for="email"
                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Email</label>
                                <div class="col-sm-12 col-md-6">
                                    <input readonly type="email" name="email" value="<?php echo e(old('email', $proveedor->email)); ?>"
                                        class="form-control" id="email">
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                <div class="col-sm-12 col-md-7">
                                    <a class="btn btn-primary mt-3 mb-3" href="<?php echo e(route('proveedor.index')); ?>"><i
                                            class="fa fa-arrow-circle-left"></i> Regresar</a>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/jquery.selectric.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.uploadPreview.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('summernote/dist/summernote-bs4.js')); ?>"></script>
    <script src="<?php echo e(asset('js/iziToast.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/page/features-post-create.js')); ?>"></script>
    <script src="<?php echo e(asset('js/panel/page/components-multiple-upload.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devian\resources\views/panel/proveedor/show.blade.php ENDPATH**/ ?>