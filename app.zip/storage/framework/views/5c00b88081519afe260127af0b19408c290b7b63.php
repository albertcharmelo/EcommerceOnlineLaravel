
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('title', __('Devia - Página no encontrada')); ?>
<?php $__env->startSection('image'); ?>
<style>
  .bg-purple-light {
    background-color: #38C0CC;
}
</style>
<div style="background-image: url('<?php echo e(asset('assets/img/devian-login.jpg')); ?>');" class="absolute pin bg-cover bg-no-repeat md:bg-left lg:bg-center">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message', __('Estamos trabjando para usted, disponible proximamente.')); ?>
<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\devian\resources\views/errors/404.blade.php ENDPATH**/ ?>