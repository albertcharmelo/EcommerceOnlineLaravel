<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
            <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i
                        class="fas fa-search"></i></a></li>
        </ul>
        
    </form>
    <ul class="navbar-nav navbar-right">
        
      
        <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
                class="nav-link notification-toggle nav-link-lg  nav-link-user">
                <img alt="image" src="<?php echo e(asset('/assets/img/avatar/avatar-1.png')); ?>"
                    class="rounded-circle mr-1">
                <div class="d-sm-none d-lg-inline-block">Hola, <?php echo e(Auth::user()->name); ?>

                    <?php echo e(Auth::user()->lname); ?></div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">


                <a href="features-settings.html" class="dropdown-item has-icon">
                    <i class="fas fa-cog"></i> Configuración
                </a>
                <div class="dropdown-divider"></div>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="d-none" id=logoutbtn></button> 
                </form>
                <a href="#" class="dropdown-item has-icon text-danger" onclick="logout()">
                    <i class="fas fa-sign-out-alt" onclick="logout()"></i> Logout
                </a>
                
            </div>
        </li>
    </ul>
</nav>

<script>
    function logout(){
        document.getElementById('logoutbtn').click();

    }
</script><?php /**PATH C:\laragon\www\devian\resources\views/panel/partials/nav.blade.php ENDPATH**/ ?>