	<!-- Slider -->
	<section class="section-slide">
		<div class="wrap-slick1 rs1-slick1">
			<div class="slick1">
				<div class="item-slick1"
					style="background-image: url(web/banner-slide-mydeviacom4-min.jpg);object-fit: cover;">
					<div class="container h-full">
						
					</div>
				</div>

				<div class="item-slick1" style="background-image: url(web/03-min.jpg);object-fit: cover;">
					<div class="container h-full">
						
					</div>
				</div>

				<div class="item-slick1" style="background-image: url(web/02-min.jpeg);object-fit: cover;">
					<div class="container h-full">
						
					</div>
				</div>
			</div>
		</div>
	</section>
<?php /**PATH C:\laragon\www\devian\resources\views/web/partials/indexSlider.blade.php ENDPATH**/ ?>